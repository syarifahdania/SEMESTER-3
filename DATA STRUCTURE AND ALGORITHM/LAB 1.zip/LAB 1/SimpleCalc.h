#ifndef SIMPLECALC_H
#define SIMPLECALC_H

class SimpleCalc{

private:

public:
   
   SimpleCalc();
   int additon(int,int);
   int substraction(int,int);
   int multiplication (int,int);
   int division (int,int);
   void displayResult()const;
	void setNum1(double newRadius);
   double getNum1() const;
   double getNum2() const;
   double getNum2() const;
};

#endif // SIMPLECALC_H
