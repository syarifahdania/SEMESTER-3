#include <iostream>
#include <conio.h>
#include "SimpleCalc.h"
using namespace std;

int main()
{
  
   return 0;
} 