#include<iostream>
#include "SimpleCalc.h"
using namespace std;
{
	int x,y;
	
	cout<<"Enter 2 numbers";
	cin>>x>>y;
	
	int SimpleCalc::addition(int &x, int&y)
	{
		return x+y;
	}
	
	int SimpleCalc::substraction(int &x, int&y))
	{
		return x-y;
	}
	
	int SimpleCalc:: multiplication(int &x, int&y)
	{
		return x*y;
	}
	
	int SimpleCalc::division(int &x, int&y)
	{
		return x/y;
	}
	
	void SimpleCalc::displayResult() const
{
   cout << "The result of addition is: " << addition() << endl;
   cout <<"The result of substraction is: " << substraction() << endl;
   cout <<"The result of multiplication is: " << multiplication() << endl;
   cout <<"The result of division is: " << division() endl;
} 
}